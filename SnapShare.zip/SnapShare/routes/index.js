var express = require('express');
var router = express.Router();
const userModel = require("./users");
const postModel = require("./post");
const passport = require('passport');
const upload = require('./multer');

const localStrategy = require("passport-local");
passport.use(new localStrategy(userModel.authenticate()));

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/login', function(req, res, next) {
  res.render('login', {error: req.flash('error')});
});
router.get('/feed', function(req, res, next) {
  res.render('feed');
});

router.post('/upload',isLoggedin, upload.single("file") ,async function(req, res, next) {
  if(!req.file) {
    return res.status(404).send("no file where given");
  }
  // user contain the infomation of login user
  const user = await userModel.findOne({username: req.session.passport.user}); 
  // create() is used to store post on db
  const post = await postModel.create({
    image: req.file.filename,
    imageText: req.body.filecaption,
    user: user._id
  });

   user.post.push(post._id);
   await user.save();
  res.redirect("/profile");
});

router.get('/profile', isLoggedin ,async function(req, res, next) {
  const user = await userModel.findOne({
    username: req.session.passport.user
  })
  .populate("post")
  // console.log(user);
  res.render("profile", {user});
});



// register code logic
router.post('/register', function(req, res) {
  const { username, email, fullname } = req.body;
  const userData = new userModel({ username, email, fullname });

  userModel.register(userData, req.body.password) 
  .then(function() {
    passport.authenticate("local")(req, res, function(){
      res.redirect("/profile");
    })
  })

})
// login code 

router.post('/login', passport.authenticate("local", {
  successRedirect: "/profile",
  failureRedirect: "/login",
  failureFlash: true
}) ,function(req, res) {})
// logout

router.get("/logout", function(req, res) {
  req.logout(function(err) {
    if (err) { return next(err); }
    res.redirect('/login');
  });
})

function isLoggedin(req, res, next) {
  if(req.isAuthenticated()) return next();
  res.redirect("/");
}


module.exports = router;
